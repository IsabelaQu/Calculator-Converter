import { Component } from '@angular/core';

@Component({
  selector: 'app-calcular-juros-simples',
  templateUrl: './calcular-juros-simples.component.html',
  styleUrls: ['./calcular-juros-simples.component.css']
})
export class CalcularJurosSimplesComponent {

}
