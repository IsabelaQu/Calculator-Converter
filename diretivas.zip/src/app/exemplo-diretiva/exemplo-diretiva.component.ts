import { Component } from '@angular/core';

@Component({
  selector: 'app-exemplo-diretiva',
  templateUrl: './exemplo-diretiva.component.html',
  styleUrls: ['./exemplo-diretiva.component.css']
})
export class ExemploDiretivaComponent {
  cidade: string = '';
  mostrarDivIf: Boolean = true;
  listClientes : any[] = [
    {nome: 'Joao', cidade: 'Curitiba', celular: '1591231424'},
    {nome: 'Renan', cidade: 'Sao Paulo', celular: '11392789904'},
    {nome: 'Mario', cidade: 'Rio de Janeiro', celular: '1328378349'},
  ];

}