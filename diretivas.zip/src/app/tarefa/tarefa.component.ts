import { Component } from '@angular/core';

class Tarefa {
  descricao: string;
  concluida: boolean;

  constructor(descricao: string, concluida: boolean) {
    this.descricao = descricao;
    this.concluida = concluida;
  }
}

@Component({
  selector: 'app-tarefa',
  templateUrl: './tarefa.component.html',
  styleUrls: ['./tarefa.component.css']
})
export class TarefaComponent {
  
  listTarefas: Tarefa[] = [
    { descricao: 'AC1', concluida: true },
    { descricao: 'Exercicio de Fixação 1', concluida: true },
    { descricao: 'AC2', concluida: false },
    { descricao: 'Exercicio de Fixação 2', concluida: true },
    { descricao: 'AF', concluida: false }
  ];


  alternarConcluida(tarefa: Tarefa) {
    tarefa.concluida = !tarefa.concluida;
  }
}
